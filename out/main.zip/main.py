import numpy as np
import os

def read_data(name):
    path = os.path.join("dataset", name)

    data_info = {}
    with open(path) as f:

        info = f.readline().split()
        data_info["b_len"] = int(info[0])
        data_info["l_len"] = int(info[1])
        data_info["d_len"] = int(info[2])

        scores = [int(sc) for sc in f.readline().split()]

        lib_data = f.readlines()
        i = 0
        while len(lib_data) > 2 * i:

            lib = [int(c) for c in lib_data[2 * i].split()]
            order = [int(c) for c in lib_data[2 * i + 1].split()]

            data_info[i] = {
                "b": lib[0],
                "sign": lib[1],
                "scan_day": lib[2],
                "order": order
            }

            i += 1

    return data_info

def get_out(data, name_out):
    path = os.path.join("out", "{}.txt".format(name_out))

    sort_order = list(range(data["l_len"]))
    t = [data[i]["sign"] * data[i]["scan_day"] for i in range(data["l_len"])]
    s = sorted(zip(sort_order, t), key= lambda x: x[1])
    new_order = [idx for (idx, sc) in s]

    idx_books = {k:True for k in range(data["b_len"])}

    with open(path, "w") as f:
        f.write("{}\n".format(data["l_len"]))
        for i in new_order:

            ord = data[i]["order"]
            new_order = []
            for o in ord:
                if idx_books[o]:
                    new_order.append(o)
                    idx_books[o] = False


            f.write("{} {}\n".format(i, data[i]["b"]))
            f.write(" ".join([str(c) for c in new_order]))
            f.write("\n")


data_name = {
    "a": "a_example.txt",
    "b": "b_read_on.txt",
    "c": "c_incunabula.txt",
    "d": "d_tough_choices.txt",
    "e": "e_so_many_books.txt",
    "f": "f_libraries_of_the_world.txt"
}

if __name__ == '__main__':
    for k in data_name.keys():
        print(k)
        data = read_data(data_name[k])
        get_out(data, k)